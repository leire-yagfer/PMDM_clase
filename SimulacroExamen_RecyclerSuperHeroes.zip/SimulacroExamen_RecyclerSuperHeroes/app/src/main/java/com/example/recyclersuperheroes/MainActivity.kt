package com.example.recyclersuperheroes

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclersuperheroes.adaptador.SuperHeroeAdaptador
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    lateinit var mirecyclerView: RecyclerView
    lateinit var miadaptador: SuperHeroeAdaptador
    lateinit var mi_toolbar: Toolbar

    lateinit var fab: FloatingActionButton

    private val lanzarCrearSuperHeroe = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){result->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            // Obtener el SuperHeroe que fue enviado desde la actividad Crear
            val nuevoSuperheroe = data?.getSerializableExtra("nuevoSuperheroe") as? SuperHeroe
            if (nuevoSuperheroe != null) {
                // Agregar el nuevo superhéroe a la lista
                SuperHeroeProveedor.SuperHeroeList.add(nuevoSuperheroe)
                miadaptador.notifyDataSetChanged()  // Notificar al adaptador para actualizar el RecyclerView
                Toast.makeText(this, "Superhéroe agregado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //Atributos para gestionar el action mode
    companion object {
        public var actionMode_activo = false

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        Inicializar_RecyclerView()
        //DEFINO EL TOOLBAR
        mi_toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(findViewById(R.id.toolbar))
        fab =findViewById(R.id.fab)
        fab.setOnClickListener{
            var mi_intent = Intent(this, Crear::class.java)
            lanzarCrearSuperHeroe.launch(mi_intent)
        }

    }

    @SuppressLint("SuspiciousIndentation")
    private fun limpiar_actionMode() {
     actionMode_activo=false;
        //Limpio el menu
        mi_toolbar.menu.clear()
        //Inflo el menu principal
        mi_toolbar.inflateMenu(R.menu.menu_principal)
        //Desaparece la flecha hacia Arriba
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        //Pongo el titulo de la aplicacion
        mi_toolbar.title=ContextCompat.getString(this,R.string.app_name)
        //Borro la lista de elementos seleccionados
        SuperHeroeProveedor.SuperHeroe_seleccionados.clear()
    }

    private fun Inicializar_RecyclerView() {
        this.mirecyclerView = findViewById(R.id.mirecyclerview)
        //Sirve para indicar que el tamaño del recyclerview no depende del contenido
        //del adaptador, se optimiza
        mirecyclerView.setHasFixedSize(true)
        //Definimos el tipo de recyclerView
        val manager = LinearLayoutManager(this)
        //Definimos el tipo de recyclerView
        mirecyclerView.layoutManager = manager
        //Fijar el adaptador
        miadaptador = SuperHeroeAdaptador(SuperHeroeProveedor.SuperHeroeList,SuperHeroeProveedor.SuperHeroe_seleccionados,
            { pos -> preparo_toolbar(pos) },
            { pos -> preparo_selecion(pos) },
            { pos -> SuperHeroeProveedor.SuperHeroeList.removeAt(pos)
                miadaptador.notifyDataSetChanged()
            }
        )
        mirecyclerView.adapter = miadaptador


    }

    //Funcion que prepara el toolbar cuando hago pulsacion larga sobre un elemento
    fun preparo_toolbar(posicion: Int) {
        //Solo preparo el toolbar si no lo he preparado antes
        if(!actionMode_activo) {
            //Primero borro el menu que hubiera en Toolbar
            mi_toolbar.menu.clear()
            //Inflo el menu de accion contextual casero
            mi_toolbar.inflateMenu(R.menu.menu_accion_contextual)
            //Indico que estamos en ActionMode
            actionMode_activo = true

            //Habilita el botón de "navegación hacia arriba" (o "back")
            // en la barra de acciones (ActionBar o Toolbar) del Activity.
            supportActionBar?.setDisplayHomeAsUpEnabled(true)

            preparo_selecion(posicion)
       }
    }

    //Funcion para guardar en una lista los elementos que voy seleccionando, clickcorto
    fun preparo_selecion(posicion: Int) {
        //Solo tiene efecto si esta el actionMode activo
        if (actionMode_activo) {

            with(SuperHeroeProveedor) {
                //val superHeroe = SuperHeroeList[posicion]
                if (!SuperHeroe_seleccionados.contains(posicion)) {
                    SuperHeroe_seleccionados.add(posicion)
                } else {
                    SuperHeroe_seleccionados.remove(posicion)
                }
                actualiza_contador()
                //Notifico de los cambios al adaptador
                miadaptador.notifyItemChanged(posicion)
            }

        }
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        when(item.itemId)
        {
            R.id.item_edit->{
                //Aunque el elemento de menu edit solamente
                //aparece con 1 elemento seleccionado me aseguro por si acaso
                if(SuperHeroeProveedor.SuperHeroe_seleccionados.size==1){
                    val superheroe_indice = SuperHeroeProveedor.SuperHeroe_seleccionados.get(0)
                    val superheroe_sellecionado = SuperHeroeProveedor.SuperHeroeList.get(superheroe_indice)

                    val dialogView = layoutInflater.inflate(R.layout.dialog_edit_superheroe, null)


                    // Obtener referencias a los EditText
                    val etSuperHeroName = dialogView.findViewById<EditText>(R.id.etSuperHeroName)
                    val etRealName = dialogView.findViewById<EditText>(R.id.etRealName)
                    val etPublisher = dialogView.findViewById<EditText>(R.id.etPublisher)

                    // Rellenar los EditText con los valores actuales
                    etSuperHeroName.setText(superheroe_sellecionado.superHeroe)
                    etRealName.setText(superheroe_sellecionado.nombre)
                    etPublisher.setText(superheroe_sellecionado.publicador)

                    val dialogo = AlertDialog.Builder(this)
                        .setView(dialogView )
                        .setTitle("Editar Superheroe")
                        .setPositiveButton("Ok"){_,_->
                            superheroe_sellecionado.superHeroe=etSuperHeroName.text.toString()
                            superheroe_sellecionado.nombre=etRealName.text.toString()
                            superheroe_sellecionado.publicador=etPublisher.text.toString()
                            actionMode_activo = false
                            miadaptador.notifyDataSetChanged()

                            limpiar_actionMode()
                        }
                        .create()
                    dialogo.show()
                }
            }
            R.id.item_delete->{
                //Salgo del action mode
                actionMode_activo=false
                //Elimino los elementos de la lista que se han seleccionado
               // miadaptador.eliminar_elementos(SuperHeroeProveedor.SuperHeroe_seleccionados)
                SuperHeroeProveedor.SuperHeroeList.removeIf {
                    SuperHeroeProveedor.SuperHeroe_seleccionados.contains(SuperHeroeProveedor.SuperHeroeList.indexOf(it))

                }
                miadaptador.notifyDataSetChanged()
                //Limpio el action mode
                limpiar_actionMode()

            }

           android.R.id.home->{
                //Se ha pulsado a la flecha de atras
                actionMode_activo=false
                limpiar_actionMode()
                //Notifico de los cambios
                miadaptador.notifyDataSetChanged()
            }
        }
        return true

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
            //Inflo el menu principal
            menuInflater.inflate(R.menu.menu_principal, menu)
            return super.onCreateOptionsMenu(menu)
        }


    private fun actualiza_contador() {
        var contador = SuperHeroeProveedor.SuperHeroe_seleccionados.size

        //Aparece el edit si solo hay un elemento seleccionado
        mi_toolbar.menu.getItem(0).setVisible(contador == 1)
        //Añado como titulo el nº de elementos seleccionados
        mi_toolbar.setTitle("$contador elementos seleccionados")

    }
}