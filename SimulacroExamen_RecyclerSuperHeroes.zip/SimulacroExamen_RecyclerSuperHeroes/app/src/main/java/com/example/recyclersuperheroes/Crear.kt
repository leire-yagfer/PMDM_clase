package com.example.recyclersuperheroes

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Crear : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear)
        val etSuper = findViewById<EditText>(R.id.editTextTextSuper)
        val etName = findViewById<EditText>(R.id.editTextTextRealName)
        val etPublisher = findViewById<EditText>(R.id.editTextTextPublisher)
        val etImage = findViewById<EditText>(R.id.editTextTextImage)
        val botonCrear = findViewById<Button>(R.id.ButtonCrear)
        val botonAtras = findViewById<Button>(R.id.ButtonAtras)

        botonCrear.setOnClickListener {
            // Verifica si los campos están llenos
            if (etSuper.text.isNotEmpty() && etName.text.isNotEmpty() && etPublisher.text.isNotEmpty() && etImage.text.isNotEmpty()) {
                // Crea un nuevo superhéroe con los datos
                val superE = SuperHeroe(
                    etSuper.text.toString(),
                    etPublisher.text.toString(),
                    etName.text.toString(),
                    etImage.text.toString()
                )

                // Prepara el Intent con el nuevo superhéroe
                val intent = Intent()
                intent.putExtra("nuevoSuperheroe", superE) // Pasa el objeto SuperHeroe al intent
                setResult(RESULT_OK, intent)  // Devuelve el resultado a la actividad anterior
                finish()  // Finaliza la actividad actual
            } else {
                // Si algún campo está vacío, muestra un mensaje
                Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
        botonAtras.setOnClickListener {
            finish()
        }
    }
}