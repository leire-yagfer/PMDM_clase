package com.example.recyclersuperheroes

import java.io.Serializable

data class SuperHeroe(var superHeroe:String, var publicador:String, var nombre:String, val foto:String): Serializable
